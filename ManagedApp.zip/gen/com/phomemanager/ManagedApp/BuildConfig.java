/** Automatically generated file. DO NOT MODIFY */
package com.phomemanager.ManagedApp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}