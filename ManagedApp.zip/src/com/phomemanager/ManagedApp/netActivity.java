package com.phomemanager.ManagedApp;

import java.io.*;
import java.net.Socket;
import com.phomemanager.ManagedApp.*;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.*;

import phonemanager.format.*;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.*;

public class netActivity extends Activity {
	
	private Socket mClientSocket=null;
	private String serverIP=null;
	private int serverPort=10000;
	private TextView textview=null;
	private TextView status=null;
	private boolean runningMessageReceiver=false;
	private boolean runningMessageSender=false;
	private Packet sendPacket=new Packet();
	private Packet recvPacket=null;
	private Toast toast=null;
	private Message message=null;
	
	ArrayList<String> mPackageFilter = new ArrayList<String>();
	int a=1;

	private final int SEND_MSG=0;
	private final int RECV_MSG=1;
	private final int MSG_PRINT=2;
	Queue<Packet> sendMsgQueue=new LinkedList<Packet>();
	Queue<Packet> recvMsgQueue=new LinkedList<Packet>();

	private ObjectOutputStream oOut=null;
	private ObjectInputStream oIn=null;	
	private final static String TAG="App_log";

	Handler Handler=new Handler(){
		@Override
		public void handleMessage(Message msg){
			try{
				switch(msg.what){
					case SEND_MSG:
				    	sendMsgQueue.offer(sendPacket);
				    	printToast("��Ŷ������ ��");
				    	Log.i(TAG, "sendpacket in handler");
				    	break;
					case RECV_MSG:
						recvPacket=recvMsgQueue.poll();
						switch(recvPacket.getCmd())
						{
							case '1':
								lock(recvPacket.getType());
								break;
							case '2' :
								unlock();
								break;
							case '3' :
								printToast("recv: " + recvPacket.getMsg());
						    	Log.i(TAG, "recv in handler: " + recvPacket.getMsg());
							    break;						
						}						
		    		    break;
					case MSG_PRINT:
						toast=Toast.makeText(netActivity.this, (String)msg.obj, Toast.LENGTH_SHORT);
					    toast.show();
						break;
				}
				
	    		}catch(Exception e){
	    			e.printStackTrace();
	    	}
		}
	};
	
	public void printToast(String data){
		if (data != null && data.length() > 0) {
			Message message = Handler.obtainMessage();
			message.what = MSG_PRINT;
			message.obj = data;
			Handler.sendMessage(message);
		}
	}
	
	public void initPacket(){
		sendPacket.setCmd('0');
		sendPacket.setType('0');
		sendPacket.setMsg("");		
	//	printToast("��Ŷ �ʱ�ȭ");
	}
	
	public void lock(char a){
		
		NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
		Notification noti = new Notification(android.R.drawable.alert_dark_frame, "����ݽ���", System.currentTimeMillis());
		Context context = getApplicationContext( );		
		PendingIntent contentIntent = PendingIntent.getActivity(context, 0, new Intent(), 0);
		noti.setLatestEventInfo(this, "�����", "������", contentIntent);
		nm.notify(1, noti);		
		//mPackageFilter.add("com.android.browser/.BrowserActivity");
		//mPackageFilter.add("com.kakao.talk/.Kakaotalk");       
		//mPackageFilter.add("com.android.settings/.Settings");
        //mPackageFilter.add("com.sec.android.app.controlpanel/.activity.JobManagerActivity"); 
        switch (a)
		{
			case '2' :				
				mPackageFilter.add("com.kakao.talk/.activity.SplashActivity"); 
				Intent i = new Intent(netActivity.this, Applock.class);
				i.putStringArrayListExtra("PACKAGE_FILTER", mPackageFilter);
				Log.i(TAG, "before startService ");
				startService(i);
				Log.i(TAG, "after startService ");
				Toast.makeText(netActivity.this,"Kakaotalk!", Toast.LENGTH_SHORT).show();
				break;	
				
			case '3' :
				mPackageFilter.add("com.android.browser/.BrowserActivity");
				Intent i1 = new Intent(netActivity.this, Applock.class);
				i1.putStringArrayListExtra("PACKAGE_FILTER", mPackageFilter);
				Log.i(TAG, "before startService ");
				startService(i1);
				Log.i(TAG, "after startService ");
				Toast.makeText(netActivity.this,"Internet!", Toast.LENGTH_SHORT).show();
				break;							
			case '4' :
				mPackageFilter.add("com.android.mms/.Mms");
				mPackageFilter.add("com.kt.mmsclient/.ui.ConverstaionList");
				Intent i2 = new Intent(netActivity.this, Applock.class);
				i2.putStringArrayListExtra("PACKAGE_FILTER", mPackageFilter);
				Log.i(TAG, "before startService ");
				startService(i2);
				Log.i(TAG, "after startService ");
				Toast.makeText(netActivity.this,"����!", Toast.LENGTH_SHORT).show();
				break;			
			case '5' :
				mPackageFilter.add("com.android.camera/.Camera");
				mPackageFilter.add("com.pantech.app.camera/.Camera"); 
				Intent i3 = new Intent(netActivity.this, Applock.class);
				i3.putStringArrayListExtra("PACKAGE_FILTER", mPackageFilter);
				Log.i(TAG, "before startService ");
				startService(i3);
				Log.i(TAG, "after startService ");
				Toast.makeText(netActivity.this,"ī�޶�!", Toast.LENGTH_SHORT).show();
				break;					
		}
	}
	
	public void unlock()
	{
		NotificationManager mangager = (NotificationManager)getSystemService( Context.NOTIFICATION_SERVICE ) ;
		mangager.cancel( 1 ) ;  // ������ Notification�� ���̵� */
		Applock.mStop=false;
		Intent i = new Intent(netActivity.this, Applock.class);
		stopService(i);
		Toast.makeText(netActivity.this,"Service Stop!", Toast.LENGTH_SHORT).show();
	}
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.net);	           
	    // TODO Auto-generated method stub	    
	    initPacket();
	    connectToServer();	    
	    printToast("���� ����");
	    runningMessageReceiver=true;
	    MessageReceiver mr=new MessageReceiver();
	    final Thread threadReceiver=new Thread(mr);
	    threadReceiver.setDaemon(true);
	    threadReceiver.start();
	    printToast("���ú� ������ ����");
	    
	    runningMessageSender=true;
	    MessageSender ms=new MessageSender();
	    final Thread threadSender=new Thread(ms);
	    threadSender.setDaemon(true);
	    threadSender.start();
	    printToast("���� ������ ����");	    
	    
	    Button home=(Button)findViewById(R.id.Gohome);
	    Button quit=(Button)findViewById(R.id.Quit);
	    
	    home.setOnClickListener(new OnClickListener(){
	    	public void onClick(View v){
	    		 Home();
	    	}
	    });
	    quit.setOnClickListener(new OnClickListener(){
	    	public void onClick(View v){
	    		NotificationManager mangager = (NotificationManager)getSystemService( Context.NOTIFICATION_SERVICE ) ;
	    		mangager.cancel( 1 ) ;  // ������ Notification�� ���̵� */
	    		//android.os.Process.killProcess(android.os.Process.myPid());
	    		//System.exit(0);
	    		close();
	    	}
	    });	   
	    Home();	 
	}
	public void onBackPressed(){}
	public void Home(){
		   	Intent intent=new Intent(Intent.ACTION_MAIN);
		    intent.addCategory(Intent.CATEGORY_HOME);
		    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		    startActivity(intent);
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
		if(runningMessageReceiver)
			runningMessageReceiver=false;
		if(runningMessageSender)
			runningMessageSender=false;
		
	}

	
	private void connectToServer(){
		try{			
			Intent it=new Intent();
			it=getIntent();
			Bundle extra=it.getExtras();
			ArrayList<String> arr = new ArrayList<String>();			
			if(mClientSocket==null){
				serverIP=extra.getString("ip");
				serverPort=Integer.parseInt(extra.getString("port"));
				mClientSocket=new Socket(serverIP,serverPort);
				status=(TextView)findViewById(R.id.statusText);				
				status.setText("���ӵ�");				
				sendPacket.setCmd('0');
	    		sendPacket.setType('9');
	    		sendPacket.setMsg("");
	    		try{
        			InputStreamReader in=new InputStreamReader(openFileInput("user_Info.txt"));
        			BufferedReader br=new BufferedReader(in);
        			String data;        			
        			while((data=br.readLine())!=null){
        				arr.add(data);
        			}        		
    	    		in.close();
        		}catch(FileNotFoundException e){e.printStackTrace();}catch(IOException e){e.printStackTrace();}	    		
        		sendPacket.setName(arr.get(0));
	    		sendPacket.setRegnumber(Integer.parseInt(arr.get(1)));
	    		sendPacket.setPhonenumber(arr.get(2));	    		
	    		message=Handler.obtainMessage();
	    		message.what=SEND_MSG;
				message.obj=sendPacket;
				Handler.sendMessage(message); // �ڵ鷯�� ����Ͽ� �����忡 �޼��� ����
			}
		}catch(IOException ee){
			ee.printStackTrace();
		}		
	}
	
	class MessageReceiver extends Thread {
		public void run() {
			try {
				oIn=new ObjectInputStream(mClientSocket.getInputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				printToast(e.getMessage());
				Log.i(TAG, "oIn error: " + e.getMessage());
			}
			
			while (runningMessageReceiver) {
				try {
					if (mClientSocket == null)
						continue;
					if(oIn==null){
						Log.i(TAG, "oIn is null");
					}
	//				oOut=new ObjectOutputStream(os);
	//				oIn=new ObjectInputStream(is);

					try { // ���ú� ��Ŷ �޴ºκ�
						recvPacket=(Packet)oIn.readObject();
						if(recvPacket==null)
							Log.i(TAG, "recvPacket is null");
						if(recvPacket!=null){
							recvMsgQueue.offer(recvPacket);
							printToast("recv: " + recvPacket.getMsg());
							Log.i(TAG, "recvPacket: " + recvPacket.getMsg());
						}
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						printToast(e.getMessage());
						Log.i(TAG, "readObject error");
					}
					if(recvPacket!=null){
						message=Handler.obtainMessage();
			    		message.what=RECV_MSG;
					//	message.obj=recvPacket;
						Handler.sendMessage(message); // �ڵ鷯�� ����Ͽ� �����忡 �޼��� ����
					}
					
	//				if (recvPacket==null) {
	//					textview=(TextView)findViewById(R.id.statusText);
	//					textview.setText("���� ����");
						
	//					printToast("���� ����");
	//					finish();
	//				} else {
						
						
	//				}
				} catch (IOException e) {
					e.printStackTrace();
					printToast(e.getMessage());
					Log.i(TAG, "readObject error ioex");
				} finally {
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
					printToast(e.getMessage());
				}
			}
		}
	}

	class MessageSender extends Thread {
		public void run() {			
			try {
				oOut=new ObjectOutputStream(mClientSocket.getOutputStream());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				printToast(e1.getMessage());
				Log.i(TAG, "oOut error: " + e1.getMessage());
			}
			while (runningMessageSender) {
				if (mClientSocket == null && oOut != null) {
					try {
						oOut.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						printToast(e.getMessage());
						Log.i(TAG, "mClientSocket is null");
					}
					oOut=null;
				}
				if (mClientSocket != null && oOut != null) {
					Packet nowSendPacket=sendMsgQueue.poll();
					
					if (nowSendPacket!=null) {
						try {
							oOut.reset();
							oOut.writeObject(nowSendPacket);
							oOut.flush();
							printToast("��Ŷ ����");
							Log.i(TAG, "writeObject");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							printToast(e.getMessage());
							Log.i(TAG, "writeObject error");
						}
	
					}
				}
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		
			if (mClientSocket != null) {
				try {
					mClientSocket.shutdownOutput();
					mClientSocket.close();
					mClientSocket = null;
					textview=(TextView)findViewById(R.id.statusText);
					textview.setText("���� ����");
					Log.i(TAG, "conncetion closed");
				} catch (IOException e) {
					e.printStackTrace();
					printToast(e.getMessage());
					Log.i(TAG, "conncetion closed error");
				}
			}
			
			if (oOut != null) {
				try {
					oOut.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					printToast(e.getMessage());
				}
				oOut = null;
			}
		}
	}
	private void close()
	{
	     finish();
	     Intent intent = new Intent(netActivity.this, ManagedAppActivity.class);
	     intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
	     intent.putExtra("KILL_ACT", true);
	     startActivity(intent);
	}

	public class packet{
		char cmd;
		char type;	
	}
}


