package com.phomemanager.ManagedApp;

import java.io.*;
import java.util.*;

import android.app.*;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.*;
import android.os.*;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;

public class ManagedAppActivity extends Activity {
    /** Called when the activity is first created. */
	EditText name;
	EditText regnumber;
	EditText phonenumber;
	@Override
	public void onCreate(Bundle savedInstanceState) {        
		super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
        final EditText name=(EditText)findViewById(R.id.name);
    	final EditText regnumber=(EditText)findViewById(R.id.regnumber);
    	final EditText phonenumber=(EditText)findViewById(R.id.phonenumber);
    	EditText serverIP=(EditText)findViewById(R.id.serverIP);  	
    	
    	//serverIP.setText("203.252.146.106");
    	//name.setText("��ȯ");     
        Button connect_to_server=(Button)findViewById(R.id.connect_to_server);
        Button Save=(Button)findViewById(R.id.save);
        Button Road=(Button)findViewById(R.id.road);
        
        Road.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){        		
        		try{
        			InputStreamReader in=new InputStreamReader(openFileInput("user_Info.txt"));
        			BufferedReader br=new BufferedReader(in);
        			String data;
        			ArrayList<String> arr = new ArrayList<String>();
        			while((data=br.readLine())!=null){
        				arr.add(data);
        			}
        			name.setText(arr.get(0));
        			regnumber.setText(arr.get(1));
    	    		phonenumber.setText(arr.get(2));
    	    		in.close();
        		}catch(FileNotFoundException e){e.printStackTrace();}catch(IOException e){e.printStackTrace();}
        	}
        });
        
        Save.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		String Name=name.getText().toString();
        		String Rnum=regnumber.getText().toString();
            	String Pnum=phonenumber.getText().toString();
            	String en="/n";
        		Toast toast=Toast.makeText(ManagedAppActivity.this, Name, Toast.LENGTH_SHORT);
        		try{
        			OutputStreamWriter os=new OutputStreamWriter(openFileOutput("user_Info.txt",Context.MODE_PRIVATE));
        			os.write(Name+"\n");
        			os.write(Rnum+"\n");
        			os.write(Pnum+"\n");
        			os.close();
        		}catch(FileNotFoundException e){e.printStackTrace();}catch(IOException e){e.printStackTrace();}        	       			
        	}
        });
        
        connect_to_server.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){     		
        		String Name=name.getText().toString();
        		String Rnum=regnumber.getText().toString();
            	String Pnum=phonenumber.getText().toString();
            	String en="/n";
        		Toast toast=Toast.makeText(ManagedAppActivity.this, Name, Toast.LENGTH_SHORT);
        		try{
        			OutputStreamWriter os=new OutputStreamWriter(openFileOutput("user_Info.txt",Context.MODE_PRIVATE));
        			os.write(Name+"\n");
        			os.write(Rnum+"\n");
        			os.write(Pnum+"\n");
        			os.close();
        		}catch(FileNotFoundException e){e.printStackTrace();}catch(IOException e){e.printStackTrace();}
        		
        		EditText serverIP=(EditText)findViewById(R.id.serverIP);
        		String ip=serverIP.getText().toString();
        		EditText portNum=(EditText)findViewById(R.id.portNum);
        		String port=portNum.getText().toString();        		
        		Intent it=new Intent(ManagedAppActivity.this,netActivity.class);
        		it.putExtra("ip", ip);
        		it.putExtra("port", port);        		
        		startActivity(it);        		
        	}        	
        });
    } 
	protected void onNewIntent(Intent intent)
	{
	     super.onNewIntent(intent);
	     boolean isKill = intent.getBooleanExtra("KILL_ACT", false);
	     if(isKill)
	     close();
	}
	     
	private void close()
	{
	     finish();
	     int nSDKVersion = Integer.parseInt(Build.VERSION.SDK);
	     if(nSDKVersion < 8)    //2.1����
	     {
	           ActivityManager actMng = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	           actMng.restartPackage(getPackageName());
	     }
	     else
	     {
	            new Thread(new Runnable() {
	                 public void run() {
	                      ActivityManager actMng = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	                      String strProcessName = getApplicationInfo().processName;
	                      while(true)
	                      {
	                           List<RunningAppProcessInfo> list = actMng.getRunningAppProcesses();
	                           for(RunningAppProcessInfo rap : list)
	                           {
	                                if(rap.processName.equals(strProcessName))
	                              {
	                                   if(rap.importance >= RunningAppProcessInfo.IMPORTANCE_BACKGROUND)
	                                        actMng.restartPackage(getPackageName());
	                                   Thread.yield();
	                                   break;
	                              }
	                         }
	                    }
	               }
	          }, "Process Killer").start();
	     }
	}
}