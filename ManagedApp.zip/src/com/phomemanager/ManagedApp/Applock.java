package com.phomemanager.ManagedApp;

import java.io.*;
import java.lang.Process;
import java.util.*;

import com.phomemanager.ManagedApp.*;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.util.*;

public class Applock extends Service{

	Thread mThread;	
	ArrayList<String> mPackageFilter;
	public static boolean mStop;
	public static boolean mPassApp=false;
	
	private final static String TAG="App_log";
	@Override
	public IBinder onBind(Intent arg0)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate()
	{
		super.onCreate();
		Log.i(TAG,"123 ");
		mStop = true;
	}
	
	@Override
	public void onDestroy()
	{
		super.onDestroy();
		mStop = false;
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		super.onStartCommand(intent, flags, startId);		
		//run		
		mPackageFilter = intent.getStringArrayListExtra("PACKAGE_FILTER"); 		
		mThread = new Thread(worker);
		mThread.setDaemon(true);
		mThread.start();		
		return START_REDELIVER_INTENT;
	}
	public void popupLock(String packageName)
	{		
		Log.i(TAG, "before runLog ");
		Intent i = new Intent();
		i.setAction(Intent.ACTION_MAIN);
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|
				Intent.FLAG_ACTIVITY_CLEAR_TOP|
				Intent.FLAG_ACTIVITY_SINGLE_TOP);
		i.addCategory(Intent.CATEGORY_HOME);
		startActivity(i);
	  	/*Intent intent=new Intent(Intent.ACTION_MAIN);
	    intent.addCategory(Intent.CATEGORY_HOME);
	    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	    startActivity(intent);*/
	}
	Runnable worker = new Runnable()
	{		
		public void run()
		{
			
			runLog();
			
		}		
	};
	private void runLog()
	{
		// TODO Auto-generated method stub
		Process process = null;		
		try
		{			
			Runtime.getRuntime().exec("/system/bin/logcat -c");			
			process = Runtime.getRuntime().exec("/system/bin/logcat -b main -s ActivityManager:I");
			Log.i(TAG,getPackageName());
		}
		catch(IOException e)
		{
			Log.e(getPackageName(),e.toString());
		}
		BufferedReader reader = null;		
		try
		{
			reader = new BufferedReader(new InputStreamReader(process.getInputStream()));			
			String line;			
			while (mStop) {
				line = reader.readLine();
				Log.i(TAG, line);
				for (int i = 0; i < mPackageFilter.size(); i++) {
					if (line.contains("cmp=" + mPackageFilter.get(i))) {
						if (!mPassApp)
						{
							/*Log.i(TAG, "after runLog ");
							String a=mPackageFilter.toString();
							PackageManager pm = getPackageManager();
							Intent io = pm.getLaunchIntentForPackage(a);
							StopActivity(io);*/
							popupLock(mPackageFilter.get(i));
						} 
						else 
						{
							mPassApp = false;
						}
					}
				}
			}
		}
		catch(IOException e)
		{
			Log.e(getPackageName(),e.toString());			
		}
		finally
		{
			try
			{
				reader.close();
			}catch (IOException e)
			{
				// TODO Auto-generated catch block
				Log.e(getPackageName(),e.toString());
			}			
			process.destroy();
			process = null;
			mThread.stop();
			mThread.destroy();
			reader = null;
			this.stopSelf();
		}
	}

	private void StopActivity(Intent io) {
		// TODO Auto-generated method stub
		
	}

}