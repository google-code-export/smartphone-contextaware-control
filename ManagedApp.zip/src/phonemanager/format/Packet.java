package phonemanager.format;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Packet implements Serializable{
	private char cmd;
	private char type;
	private String msg;
	private String name;
	private int regnumber;
	private String phonenumber;
	
	public void setCmd(char cmd){
		this.cmd=cmd;
	}
	
	public void setType(char type){
		this.type=type;
	}
	
	public void setMsg(String msg){
		this.msg=msg;
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public void setRegnumber(int regnumber){
		this.regnumber=regnumber;
	}
	
	public void setPhonenumber(String phonenumber){
		this.phonenumber=phonenumber;
	}
	
	public char getCmd(){
		return cmd;
	}
	
	public char getType(){
		return type;
	}
	
	public String getMsg(){
		return msg;
	}
	
	public String getName(){
		return name;
	}
	
	public int getRegnumber(){
		return regnumber;
	}
	
	public String getPhonenumber(){
		return phonenumber;
	}
}
